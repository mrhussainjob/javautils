package com.easylearn;

public class Triangle {
	Point a;
	Point b;
	Point c;
	float area;
 
	public Triangle(Point a, Point b, Point c) {
		super();
		this.a = a;
		this.b = b;
		this.c = c;
	}

	public Point getA() {
		return a;
	}

	public void setA(Point a) {
		this.a = a;
	}

	public Point getB() {
		return b;
	}

	public void setB(Point b) {
		this.b = b;
	}

	public Point getC() {
		return c;
	}

	public void setC(Point c) {
		this.c = c;
	}

	public float getArea() {
		
		float area = (a.x * (b.y - c.y) + b.x * (c.y - a.y) + c.x * (a.y - b.y)) * 0.5f;
		return Math.abs(area);
		
	}

	public void setArea(float area) {
		this.area = area;
	}

	
	public boolean equals(Triangle one) {

		System.out.println("Triangle one area :"+this.getArea()+" Triangle two area :"+one.getArea());
		if (this.getArea()==one.getArea()) {
			
			System.out.println("Triangles are Equal");
			return true;
		}
		else {
			System.out.println("Triangles are not Equal");
			return false;
		}

        }
	
	public static void triangleEqualityChecker(Triangle one,Triangle two) {
		
		
		
	}	
	

}
