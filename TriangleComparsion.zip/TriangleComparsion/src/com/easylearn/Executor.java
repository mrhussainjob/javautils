package com.easylearn;

public class Executor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//1st method by sides
		
		Point p1=new Point(1, 10);
		Point p2=new Point(2, 40);
		Point p3=new Point(3, 30);
		Triangle t1=new Triangle(p1,p2,p3);
		
		Point p11=new Point(1, 10);
		Point p22=new Point(2, 50);
		Point p33=new Point(3, 30);

		Triangle t2=new Triangle(p11,p22,p33);
		t1.equals(t2);
		
	}

}
