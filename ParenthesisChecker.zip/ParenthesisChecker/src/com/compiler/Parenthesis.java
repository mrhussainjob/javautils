package com.compiler;

import java.util.Stack;

public class Parenthesis {

	static boolean areBracketsBalanced(String expr) throws IllegalArgumentException{
		//
		Stack<Character> stack = new Stack<Character>();
		char check = ' ';
		if (expr.length()==0) {
			
		 throw new IllegalArgumentException();
		}
		for (int i = 0; i < expr.length(); i++) {
			char x = expr.charAt(i);
			if (x == '(') {
				stack.push(x);
				continue;
			}
			if (stack.isEmpty())
				return false;
			switch (x) {
			case ')':
				check = stack.pop();
				break;
			}
		}
		return (stack.isEmpty());
	}
}
