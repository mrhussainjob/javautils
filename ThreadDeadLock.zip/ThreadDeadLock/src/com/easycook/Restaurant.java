package com.easycook;

public class Restaurant{
	   public static Object order1 = new Object();
	   public static Object order2 = new Object();
	   
	   public static void main(String args[]) {
		  FoodServer T1 = new FoodServer();
	      FoodPreparer T2 = new FoodPreparer();
	      T1.start();
	      T2.start();
	   }
	   
	   private static class FoodServer extends Thread {
		   
	      public void run() {
	         synchronized (order1) {
	            System.out.println("Thread 1: Taking order1...");
	            
	            try { Thread.sleep(10); }
	            catch (InterruptedException e) {}
	            System.out.println("Thread 1: Waiting for order 2...");
	            
	            synchronized (order2) {
	               System.out.println("Thread 1: Holding order 1 & 2...");
	            }
	         }
	      }
	   }
	   private static class FoodPreparer extends Thread {
	      public void run() {
	         synchronized (order1) {
	            System.out.println("Thread 2: Holding order 2...");
	            
	            try { Thread.sleep(10); }
	            catch (InterruptedException e) {}
	            System.out.println("Thread 2: Waiting for order 1...");
	            
	            synchronized (order2) {
	               System.out.println("Thread 2: Holding order 1 & 2...");
	            }
	         }
	      }
	   } 
	}