package com.compiler;

public class Executor {

	public static void main(String[] args) {

		System.out.println("Test1 " +Parenthesis.areBracketsBalanced("()"));
		System.out.println("Test2 " +Parenthesis.areBracketsBalanced("(()"));
		System.out.println("Test3 " +Parenthesis.areBracketsBalanced(")"));
		
		try {
		System.out.println("Test4 for empty ");
		System.out.print(Parenthesis.areBracketsBalanced(""));
		}
		catch(Exception e) {
		e.printStackTrace();
		}
		
	}

}
